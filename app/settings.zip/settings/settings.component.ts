import { Component, OnInit } from '@angular/core';
import {
  FormControl,
  FormGroup,
  FormBuilder,
  Validators,
} from '@angular/forms';
// import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { SettingsService } from '../core/_services/settings.service';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss'],
})
export class SettingsComponent implements OnInit {
  closeResult: string = '';
  settingForm!: FormGroup;
  settingCoraId!: number;
  UserCoraId: any;
  tempData: any

  // = [
  //   {
  //     trackingSteps: 'Post-Delivery Inspection',
  //     Include: 'yes',
  //     Sequence: '1',
  //     dependencies: 'Temp Tag',
  //     notifications: 'sales person',
  //     within: '2 days',
  //     type: 'automatic',
  //     dmsEvidence:
  //       'Generally The Deal Date – There Should Be A Service Record For The PDI (Post-Delivery, Not Pre-Delivery)',
  //     status: 'Active',
  //   },
  //   {
  //     trackingSteps: 'pre-Delivery Inspection',
  //     Include: 'yes',
  //     Sequence: '2',
  //     dependencies: 'Temp Tag',
  //     notifications: 'sales person',
  //     within: '5 days',
  //     type: 'automatic',
  //     dmsEvidence:
  //       'Generally The Deal Date – There Should Be A Service Record For The PDI (Post-Delivery, Not Pre-Delivery)',
  //     status: 'Active',
  //   },
  //   {
  //     trackingSteps: 'pre-Delivery ',
  //     Include: 'no',
  //     Sequence: '3',
  //     dependencies: 'Temp Tag',
  //     notifications: 'controller',
  //     within: '7 days',
  //     type: 'manual',
  //     dmsEvidence:
  //       'Generally The Deal Date – There Should Be A Service Record For The PDI (Post-Delivery, Not Pre-Delivery)',
  //     status: 'In Active',
  //   },
  // ];


  constructor(
    // private modalService: NgbModal,
    private formBuilder: FormBuilder,
    private service: SettingsService,
    private settingservice :SettingsService
  ) {}

  ngOnInit(): void {
    // this.settingCoraId = 1;
    // this.getSettings(this.settingCoraId);
    // this.settingForm = new FormGroup({
    //   trackingSteps: new FormControl(),
    //   inlineRadioOptions: new FormControl(),
    //   sequence: new FormControl(),
    //   dependencies: new FormControl(),
    //   notifications: new FormControl(),
    //   within: new FormControl(),
    //   type: new FormControl(),
    //   dmsEvidence: new FormControl(),
    // });
    this.UserCoraId=localStorage.getItem('UserCoraId')
    this.settingservice.GetSettingsView(this.UserCoraId)
    .subscribe((res:any)=>{
      console.log('SettingData',res);
      this.tempData=res

    })
  }

  getSettings(id: number) {
    let token = localStorage.getItem('UserToken');
  }
  addSetting(data: any) {}
  EditRow(content: any, data: any) {
    // this.modalService.open(content);
    console.log(data);
  }
  DeleteRow() {}
  open(content: any) {
    // this.modalService.open(content)
  }
  close() {
    // this.modalService.dismissAll();
  }
}

